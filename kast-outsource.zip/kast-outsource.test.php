<?php

$sms_status_url = 'http://api.ame22.wyrls.net/broadcast/job/8119';

$options = array(
                        'Date'              => date('r'),
                        'Content-type'      => '',
                        'Content-MD5'       => '',
                        'Content-length'    => 0,
                    );

$uri = parse_url($sms_status_url);

$sign_data = array(
                        'GET',
                        $uri['path'],
                        $options['Date'],
                        $options['Content-type'],
                        $options['Content-length'],
                        $options['Content-MD5']
                    );

$sign_string = implode("\n", $sign_data) . "\n";

        $priv_key = openssl_get_privatekey(file_get_contents("kast-outsource.priv"));
        openssl_sign($sign_string, $signature, $priv_key);

        $headers = array('Authorization: MCWS u/128/kast-outsource:' . trim(base64_encode($signature)),
                            'Accept: application/vnd.net.wyrls.BroadcastJobList-v1+json',
                            'Date: ' . $options['Date']
                    );

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $sms_status_url);
        curl_setopt($ch, CURLOPT_POST, FALSE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);

$response_body = curl_exec($ch);
$httpresponse = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

var_dump($httpresponse, $response_body);

