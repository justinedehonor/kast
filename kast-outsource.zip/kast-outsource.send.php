<?php

$msisdn_list_uri = 'http://mob-ads.wyrls.net/test.csv';
$messages = 'test kast';

$req_body_arr = array(
	'msisdn_list_uri'   => $msisdn_list_uri,
            'message'           => stripslashes($messages),
            'message2'          => NULL,
            'message3'          => NULL,
            'date'              => date('c'),
            'shortcode'         => 'eggrts',
            'shortcode_alias'   => 'MOBILEADS',
            'usagetype'         => 'KAST_TEST_BCAST',

);

$request_body = json_encode($req_body_arr);


$options = array(
                        'Date'              => date('r'),
                        'Content-type'      => 'application/vnd.net.wyrls.BroadcastJob-v1+json',
                        'Content-MD5'       => base64_encode(pack('H*', md5($request_body))),
                        'Content-length'    => strlen($request_body),
                    );
$url = 'http://api.ame22.wyrls.net/broadcast/jobs';
$uri = parse_url($url);

$sign_data = array(
                        'POST',
                        $uri['path'],
                        $options['Date'],
                        $options['Content-type'],
                        $options['Content-length'],
                        $options['Content-MD5']
                    );

$sign_string = implode("\n", $sign_data) . "\n";

$priv_key = openssl_get_privatekey(file_get_contents("kast-outsource.priv"));

openssl_sign($sign_string, $signature, $priv_key);

        $headers = array('Authorization: MCWS ' . 'u/128/kast-outsource:' . trim(base64_encode($signature)),
                            'Date: ' . $options['Date'],
                            'Content-Type: ' . $options['Content-type'],
                            'Content-MD5: ' . $options['Content-MD5'],
                    );

        $ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, FALSE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $request_body);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);

        $response = curl_exec($ch);
$httpresponse = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

var_dump($httpresponse, $response);
